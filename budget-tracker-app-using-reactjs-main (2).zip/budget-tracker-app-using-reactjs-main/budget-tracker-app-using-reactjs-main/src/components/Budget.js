
import React, { useContext } from 'react';
import { AppContext } from '../context/AppContext';

//Create a new component called Budget
const Budget = () => {
	const { budget } = useContext(AppContext);
	const [currentState, setCurrentState] = React.useState();

	return (
		<div className='alert alert-secondary'>
			<span>Budget: Rs 
			</span>
		</div>
	);
};

export default Budget;